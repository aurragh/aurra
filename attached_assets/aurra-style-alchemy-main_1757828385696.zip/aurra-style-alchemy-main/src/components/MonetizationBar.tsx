
import React from "react";
import { User, Image, List } from "lucide-react";

const MonetizationBar: React.FC = () => (
  <section className="w-full py-8 animate-fade-in">
    <div className="max-w-5xl mx-auto flex flex-col md:flex-row gap-6 justify-between items-center bg-gradient-to-r from-aurra-blue via-white/70 to-aurra-pink/30 rounded-2xl shadow border border-muted px-8">
      <div className="flex items-center gap-3">
        <User size={32} className="text-aurra-pink" />
        <div>
          <div className="font-bold font-montserrat text-lg">Freemium + Premium</div>
          <div className="text-xs text-muted-foreground">Try for free, unlock unlimited AI with Aurra Pro.</div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Image size={32} className="text-aurra-blue" />
        <div>
          <div className="font-bold font-montserrat text-lg">Digital Fashion Ownership</div>
          <div className="text-xs text-muted-foreground">Mint outfits as NFTs (coming soon!)</div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <List size={32} className="text-aurra-lavender" />
        <div>
          <div className="font-bold font-montserrat text-lg">Shop + Earn</div>
          <div className="text-xs text-muted-foreground">Shop looks and earn rewards. Affiliate & more.</div>
        </div>
      </div>
    </div>
  </section>
);

export default MonetizationBar;
