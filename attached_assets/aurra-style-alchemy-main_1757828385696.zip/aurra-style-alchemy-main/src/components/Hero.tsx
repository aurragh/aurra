
import React from "react";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

const Hero: React.FC<{scrollToDemo?: () => void}> = ({ scrollToDemo }) => (
  <section className="w-full py-20 px-4 md:px-0 flex flex-col items-center bg-gradient-to-br from-aurra-pink/30 via-aurra-lavender/15 to-aurra-blue/20 rounded-3xl shadow-lg mb-6 animate-fade-in">
    <div className="max-w-4xl flex flex-col items-center text-center">
      <span className="inline-flex items-center gap-2 text-aurra-pink font-bold uppercase text-xs tracking-wider mb-4">AURRA.AI <Sparkles size={20} className="inline" /></span>
      <h1 className="text-5xl md:text-6xl font-bold font-montserrat leading-tight mb-6 text-primary drop-shadow-sm">
        Effortlessly create your <span className="bg-gradient-to-r from-aurra-pink via-aurra-lavender to-aurra-blue bg-clip-text text-transparent">perfect look</span> for any event
      </h1>
      <p className="text-xl md:text-2xl text-muted-foreground max-w-xl mb-8 font-montserrat">
        Hyper-personalized AI outfit recommendations. Style, mood, and body—unlocked.
      </p>
      <Button
        size="lg"
        className="px-8 py-4 text-lg font-bold rounded-full bg-gradient-to-r from-aurra-pink via-aurra-lavender to-aurra-blue hover:scale-105 shadow-xl transition-all"
        onClick={scrollToDemo}
      >
        Get Your Personalized Look
      </Button>
    </div>
  </section>
);

export default Hero;
