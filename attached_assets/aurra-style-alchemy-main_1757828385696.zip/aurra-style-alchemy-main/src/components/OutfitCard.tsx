
import React from "react";
import { Button } from "@/components/ui/button";
import { Image, File } from "lucide-react";

interface OutfitCardProps {
  form: any;
  // placeholder for AI output
}

// Use Unsplash URLs for guaranteed availability
const exImages = [
  "https://images.unsplash.com/photo-1649972904349-6e44c42644a7",
  "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158",
  "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5",
];

const randomImage = () =>
  exImages[Math.floor(Math.random() * exImages.length)];

const OutfitCard: React.FC<OutfitCardProps> = ({ form }) => {
  if (!form) return null;
  // AI "generated" outfit sample
  return (
    <div className="rounded-3xl bg-gradient-to-br from-aurra-blue/50 via-white/80 to-aurra-pink/40 p-8 mt-10 shadow-xl flex flex-col md:flex-row items-center gap-7 border border-muted animate-fade-in">
      <div className="w-[200px] h-[280px] bg-gray-100 rounded-2xl shadow-lg overflow-hidden flex items-center justify-center flex-shrink-0 relative border-4 border-white">
        <img
          src={randomImage()}
          alt="Generated Outfit"
          className="object-cover w-full h-full"
          style={{ minHeight: 180 }}
        />
        <span className="absolute bottom-2 right-2 bg-white text-xs rounded-full px-3 py-0.5 text-aurra-lavender font-bold shadow-lg">AI OUTFIT</span>
      </div>
      <div className="flex-1">
        <h3 className="text-2xl font-montserrat font-bold mb-2">Your Personalized Look</h3>
        <ul className="mb-3 text-muted-foreground text-base font-montserrat">
          <li><b>Event:</b> {form.event}</li>
          <li><b>Mood:</b> {form.mood?.length ? form.mood.join(", ") : "N/A"}</li>
          <li><b>Confidence:</b> {form.body?.length ? form.body.join(", ") : "N/A"}</li>
          <li><b>Height:</b> {form.height || "N/A"}</li>
          <li><b>Body Shape:</b> {form.shape}</li>
        </ul>
        <div className="mb-4 text-gray-700">
          <p>
            <span className="italic text-aurra-pink">
              “Confidently stylish for your {form.event.toLowerCase()}—{form.mood.length ? form.mood[0].toLowerCase() : "unique"} energy shines. Accentuates your {form.body.length ? form.body[0].toLowerCase() : "favorite feature"}.”
            </span>
          </p>
        </div>
        <div className="flex flex-col md:flex-row gap-3">
          <Button variant="secondary" className="px-6 rounded-full flex gap-2 items-center font-semibold">Shop Similar <File size={18} /></Button>
          <Button disabled className="px-6 rounded-full bg-gradient-to-r from-aurra-pink via-aurra-lavender to-aurra-blue flex gap-2 items-center font-semibold opacity-80 cursor-not-allowed">Mint as NFT (Coming Soon)</Button>
        </div>
      </div>
    </div>
  );
};

export default OutfitCard;

