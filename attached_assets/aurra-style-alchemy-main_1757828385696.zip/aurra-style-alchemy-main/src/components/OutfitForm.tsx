
import React, { useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { List, User, Calendar } from "lucide-react";

// Demo select data
const events = [
  "Wedding",
  "Gala",
  "Casual Outing",
  "Date Night",
  "Festival",
  "Job Interview",
  "Graduation",
  "Other"
];
const moods = [
  "Confident", "Chill", "Playful", "Bold", "Romantic", "Edgy", "Creative"
];
const bodyZones = [
  "Legs", "Arms", "Waist", "Back", "Shoulders", "Neckline"
];

const bodyShapes = [
  "Hourglass", "Rectangle", "Pear", "Apple", "Athletic", "Prefer not to say"
];

// Main Form Component
const OutfitForm: React.FC<{onGenerate: (form: any) => void; loading?: boolean;}> = ({ onGenerate, loading }) => {
  const [event, setEvent] = useState(events[0]);
  const [mood, setMood] = useState<string[]>([]);
  const [body, setBody] = useState<string[]>([]);
  const [height, setHeight] = useState("");
  const [shape, setShape] = useState(bodyShapes[0]);

  // Animation ref for scroll
  const demoRef = useRef(null);

  function toggle<T>(arr: T[], val: T) {
    return arr.includes(val) ? arr.filter((i) => i !== val) : [...arr, val];
  }

  return (
    <div className="rounded-3xl bg-white/70 shadow-lg p-8 max-w-2xl mx-auto flex flex-col gap-7 border border-muted animate-fade-in" ref={demoRef}>
      <h2 className="text-3xl font-bold mb-2 text-center font-montserrat text-aurra-pink">Try the Aurra.ai Demo</h2>
      <form
        className="flex flex-col gap-5"
        onSubmit={(e) => {
          e.preventDefault();
          onGenerate({
            event,
            mood,
            body,
            height,
            shape
          });
        }}
      >
        {/* Event Type */}
        <div>
          <label className="font-semibold flex items-center gap-2 text-muted-foreground text-base mb-1">
            <Calendar size={16} /> Event:
          </label>
          <select className="bg-white border px-4 py-2 rounded-lg focus:ring-aurra-pink shadow-sm w-full"
            value={event} onChange={e => setEvent(e.target.value)}
          >
            {events.map((e, i) => (
              <option key={i} value={e}>{e}</option>
            ))}
          </select>
        </div>
        {/* Mood/Energy */}
        <div>
          <label className="font-semibold flex items-center gap-2 text-muted-foreground text-base mb-1">
            <List size={16} /> Mood/Energy:
          </label>
          <div className="flex flex-wrap gap-2">
            {moods.map((m) => (
              <button
                key={m}
                type="button"
                className={`px-3 py-1 rounded-full border font-medium text-sm
                  ${mood.includes(m) ? "bg-aurra-pink text-white border-aurra-pink shadow-lg" : "bg-white border-muted text-muted-foreground"}
                  hover:bg-aurra-pink/80 hover:text-white transition-colors`}
                onClick={() => setMood(toggle(mood, m))}
              >{m}</button>
            ))}
          </div>
        </div>
        {/* Body Confidence */}
        <div>
          <label className="font-semibold flex items-center gap-2 text-muted-foreground text-base mb-1">
            <User size={16} /> Body Confidence Zone(s):
          </label>
          <div className="flex flex-wrap gap-2">
            {bodyZones.map((z) => (
              <button
                key={z}
                type="button"
                className={`px-3 py-1 rounded-full border font-medium text-sm
                  ${body.includes(z) ? "bg-aurra-blue text-white border-aurra-blue shadow-lg" : "bg-white border-muted text-muted-foreground"}
                  hover:bg-aurra-blue/70 hover:text-white transition-colors`}
                onClick={() => setBody(toggle(body, z))}
              >{z}</button>
            ))}
          </div>
        </div>
        {/* Height & Shape */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="grow">
            <label className="font-semibold text-muted-foreground text-base mb-1">Height (cm/inches):</label>
            <Input
              placeholder="e.g. 168cm or 5'6&quot;"
              value={height}
              onChange={e => setHeight(e.target.value)}
              className="border px-4 py-2 rounded-lg"
            />
          </div>
          <div className="grow">
            <label className="font-semibold text-muted-foreground text-base mb-1">Body Shape:</label>
            <select
              className="bg-white border px-4 py-2 rounded-lg focus:ring-aurra-pink shadow-sm w-full"
              value={shape}
              onChange={e => setShape(e.target.value)}
            >
              {bodyShapes.map((s, i) => (
                <option key={i} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
        <Button
          className="w-full mt-4 px-4 py-2 rounded-full bg-gradient-to-r from-aurra-pink via-aurra-lavender to-aurra-blue font-semibold text-lg shadow-lg transition-all hover:scale-[1.03]"
          disabled={loading}
          type="submit"
        >
          {loading ? "Generating..." : "Generate Your Outfit"}
        </Button>
      </form>
    </div>
  );
};

export default OutfitForm;
