
import React, { useRef, useState } from "react";
import Hero from "@/components/Hero";
import OutfitForm from "@/components/OutfitForm";
import OutfitCard from "@/components/OutfitCard";
import ExampleGrid from "@/components/ExampleGrid";
import MonetizationBar from "@/components/MonetizationBar";
import { Toaster } from "@/components/ui/toaster";

const Index = () => {
  const formRef = useRef<HTMLDivElement | null>(null);
  const [form, setForm] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleScrollToForm = () => {
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 100);
  };

  return (
    <main className="w-full min-h-screen bg-background font-montserrat relative px-0">
      {/* Fake Nav */}
      <header className="w-full flex items-center justify-between py-8 px-4 md:px-0 max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="block w-3 h-3 bg-gradient-to-br from-aurra-pink via-aurra-lavender to-aurra-blue rounded-full mr-2"></span>
          <span className="font-bold tracking-wider text-lg md:text-2xl text-primary font-montserrat">Aurra.ai</span>
        </div>
        <nav className="flex gap-5">
          <a href="#demo" className="text-muted-foreground font-semibold hover:text-aurra-pink transition">Try Demo</a>
          <a href="#how" className="text-muted-foreground font-semibold hover:text-aurra-lavender transition">How It Works</a>
          <a href="#inspire" className="text-muted-foreground font-semibold hover:text-aurra-blue transition">Inspire Me</a>
        </nav>
      </header>
      {/* Hero */}
      <Hero scrollToDemo={handleScrollToForm} />
      {/* Demo Outfit Generator */}
      <div ref={formRef} id="demo" className="scroll-mt-16">
        <OutfitForm
          onGenerate={(f) => {
            setLoading(true);
            setTimeout(() => {
              setForm(f); // Simulate AI output.
              setLoading(false);
            }, 1200);
          }}
          loading={loading}
        />
      </div>
      {/* AI Output */}
      <OutfitCard form={form} />
      {/* Example Grid */}
      <div id="inspire">
        <ExampleGrid />
      </div>
      {/* Monetization / How It Works bar */}
      <div id="how">
        <MonetizationBar />
      </div>
      <Toaster />
      <footer className="py-10 text-center text-muted-foreground text-xs font-montserrat">
        &copy; {new Date().getFullYear()} Aurra.ai &mdash; Digital Fashion & AI Styling for Self-Expression
      </footer>
    </main>
  );
};

export default Index;
